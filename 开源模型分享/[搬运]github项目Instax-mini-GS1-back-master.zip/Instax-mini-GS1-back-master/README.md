# Instax-mini-GS1-back
An Instax mini film back for Bronica GS1 6x7 format camera
Software: Solidworks 2018
项目来源：https://github.com/LuZening/Instax-mini-GS1-back
